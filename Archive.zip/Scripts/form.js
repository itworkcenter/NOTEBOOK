/* textarea automatic height */
;!function (window, $, undefined) {
	var TextareaFix = (function () {
		var KEYCODE = [8,35,36,37,38,39,40,46];
		function TextareaFix(bindDom, options) {
			this.$this = bindDom;
			this.setOptions(options);
			this.render();
		}

		TextareaFix.prototype.defaultOpts = {
			limitLen: false,
			limitNum: 3000,
			counterElement: '',
			beforeCallback: function (self) {}
		};

		TextareaFix.prototype.setOptions = function (options) {
			this.opts = $.extend({}, this.defaultOpts, options);
		};

		TextareaFix.prototype.calculate = function (obj) {
			var self = this.$this;
			var opts = this.opts;
			if (opts.limitLen) {
				var _count = self.val().length;

				if (_count > opts.limitNum) {
					//self.val(self.val().substring(0, opts.limitNum));
					/*_count = opts.limitNum;
				}

				if(_count == opts.limitNum){*/
					$(opts.counterElement).css('color', '#e10000');
				}else{
					$(opts.counterElement).css('color', '#707070');
				}
				$(opts.counterElement).html(_count);
			}

			var content = self.val();
			content = content.replace(/\n/g, '<br>');

			$('.stuff-textarea').css('width', self.innerWidth()).html(content + '<br>');

			self.css('height', $('.stuff-textarea').innerHeight());

		};

		TextareaFix.prototype.bindEvent = function () {
			var _self = this;
			$(window).bind('resize.' + _self.$this.constructor.expando, function () {
				//_self.opts.resizeBeforeCallback(_self.$this);
				_self.calculate(_self.$this);
			});
		};

		TextareaFix.prototype.unBindEvent = function () {
			$(window).unbind('.' + this.$this.constructor.expando);
		};

		TextareaFix.prototype.render = function () {
			var opts = this.opts;
			var _self = this;

			if ($('.stuff-textarea').length == 0) {
				var hiddenDiv = $(document.createElement('div'));
				hiddenDiv.addClass('stuff-textarea');
				$('body').append(hiddenDiv);
			}
			opts.beforeCallback(this.$this);

			this.$this.addClass('txtstuff');

			_self.calculate();

			this.$this.keydown(function (e) {
				if(
					$(opts.counterElement).html() == opts.limitNum && 
					(
						KEYCODE.indexOf(e.keyCode) < 0 &&
						!(e.ctrlKey == true && e.keyCode == 65)
					)
				){
					//return false;
				}
				// if ($(opts.counterElement).html() == opts.limitNum && 
				// 	((KEYCODE.indexOf(e.keyCode) < 0 && e.ctrlKey == false)
    //                      || (e.ctrlKey == true && e.keyCode == 86))) {
    //                     return false;
    //                 }
			});

			this.$this.keyup(function (e) {
				_self.calculate();
			});
			this.$this.change(function () {
				_self.calculate();
			});
			this.bindEvent();

			return this;
		};
		return TextareaFix;
	})();
	$.fn.TextareaFix = function (opts) {
		var $this = $(this),
			data = $this.data();

		if (data.TextareaFix) {
			delete data.TextareaFix;
		}
		if (opts !== false) {
			data.TextareaFix = new TextareaFix($this, opts);
		}

		return data.TextareaFix;
	};
}(window, jQuery);


/* format price  */
Number.prototype.formatPrice = function(c, d, t){
	var n = this, 
	    c = isNaN(c = Math.abs(c)) ? 2 : c, 
	    d = d == undefined ? "." : d, 
	    t = t == undefined ? "," : t, 
	    s = n < 0 ? "-" : "", 
	    i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
	    j = (j = i.length) > 3 ? j % 3 : 0;
	    
	return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};
;!function (window, $, undefined) {
	var PriceInputBox = (function() {
		var ctrlDown = false;
		function PriceInputBox(bindDom, options) {
			this.$this = bindDom;
			this.setOptions(options);
			this.render();
		};
		
		PriceInputBox.prototype.defaultOpts = {
			decimalPlaces: 0
		};
		
		PriceInputBox.prototype.setOptions = function(options) {
			this.opts = $.extend({}, this.defaultOpts, options);
		};
		
		PriceInputBox.prototype.bindEvent = (function() {
			jQuery(document).keydown(function(e) {
				if ((e.keyCode == 17) || (e.keyCode == 91)) ctrlDown = true;
			}).keyup(function(e) {
				if ((e.keyCode == 17) || (e.keyCode == 91)) ctrlDown = false;
			});
		});
		
		PriceInputBox.prototype.render = function() {
			var opts = this.opts;
			var _self = this;
			var formatPriceTimer, formatPriceT, formatPriceSelf;
						
			this.$this.keydown(function (e) {
		        // Allow: backspace, delete, tab, escape, enter, comma and period
		        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 188, 190]) !== -1 ||
		        	// Allow: Ctrl+A, Ctrl+C, Ctrl+V and Ctrl+X
					(ctrlDown && (e.keyCode == 65 || e.keyCode == 67 || e.keyCode == 86 || e.keyCode == 88)) ||
		            // Allow: home, end, left, right
		            (e.keyCode >= 35 && e.keyCode <= 39)) {
		                 // let it happen, don't do anything
		                 return;
		        }
		        // Ensure that it is a number and stop the keypress
		        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		            e.preventDefault();
		        }
		    }).keyup(function(){
				var num = this.value.replace(/[^0-9\,\.]/g,'');
				//this.value = num;
				
				formatPriceSelf = jQuery(this);
				formatPriceT = num;
				
				if (formatPriceTimer) clearTimeout(formatPriceTimer);
				
				formatPriceTimer = setTimeout(function(){
					var price = Number((formatPriceT).replace(/,/g, ''));
					formatPriceSelf.val(price.formatPrice(opts.decimalPlaces));
				}, 1000);
		
			}).blur(function(){
				var price = Number((this.value).replace(/,/g, ''));
				this.value = price.formatPrice(opts.decimalPlaces);
			});
						
			this.bindEvent();
			return this;
		};
		
		return PriceInputBox;
	})();
	
	$.fn.PriceInputBox = function(opts) {
		var $this = $(this),
			data = $this.data();
			
		if (data.PriceInputBox) {
			delete data.PriceInputBox;
		}
		if (opts !== false) {
			data.PriceInputBox = new PriceInputBox($this, opts);
		}

		return data.PriceInputBox;
	};
	
}(window, jQuery);
