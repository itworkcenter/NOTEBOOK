jQuery(window).load(function(){
	/* banner, hero module */
	var bannerSwiper = new Swiper('#heroModule',{
		prevButton: '#heroModule .swiper-button-prev',
		nextButton: '#heroModule .swiper-button-next',
		centeredSlides: true,
		loop: true,
		autoplay: 5000
	});
	
	jQuery('#heroModule').mouseenter(function(){
		bannerSwiper.stopAutoplay();
	}).mouseleave(function(){
		bannerSwiper.startAutoplay();
	});
	
	jQuery('#heroModule .swiper-button-prev, #heroModule .swiper-button-next').one('click', function(){
		jQuery('#heroModule').unbind();
	});
});