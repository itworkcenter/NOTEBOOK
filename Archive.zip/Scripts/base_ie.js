function swiperBox_single(box) {
	var swiper = new Swiper(box + ' .swiper-container', {
        pagination: box + ' .swiper-pagination',
        paginationClickable: true,
        calculateHeight: true,
        loop: true
    });
    jQuery(box + ' .swiper-box-arrow-prev').click(function(){
		swiper.swipePrev();
	});
	jQuery(box + ' .swiper-box-arrow-next').click(function(){
		swiper.swipeNext();
	});
}

function swiperBox_3(box) {
	var swiper = new Swiper(box + ' .swiper-container', {
        pagination: box + ' .swiper-pagination',
        paginationClickable: true,
        calculateHeight: true,
        slidesPerGroup: 3,
        slidesPerView: 3,
        spaceBetween: 10,
        loop: true
    });
    jQuery(box + ' .swiper-box-arrow-prev').click(function(){
		swiper.swipePrev();
	});
	jQuery(box + ' .swiper-box-arrow-next').click(function(){
		swiper.swipeNext();
	});
}

function swiperBox_responsive_3(box) {
	var swiper = new Swiper(box + ' .swiper-container', {
        pagination: box + ' .swiper-pagination',
        paginationClickable: true,
        calculateHeight: true,
        slidesPerGroup: 3,
        slidesPerView: 3,
        spaceBetween: 10,
        loop: true
    });
    jQuery(box + ' .swiper-box-arrow-prev').click(function(){
		swiper.swipePrev();
	});
	jQuery(box + ' .swiper-box-arrow-next').click(function(){
		swiper.swipeNext();
	});
	
	var _w1 = document.documentElement.clientWidth;
	var _w2 = document.body.clientWidth;
	if ((_w1 || _w2) <= 1100) {
		swiper.params.slidesPerGroup = 1;
		swiper.params.slidesPerView = 1;
		swiper.reInit();
		swiper.resizeFix();
	}else if ((_w1 || _w2) <= 1360) {
		swiper.params.slidesPerGroup = 2;
		swiper.params.slidesPerView = 2;
		swiper.reInit();
		swiper.resizeFix();
	}
	
	var resizeTimer = null;
	$(window).bind('resize', function(e){
		if (resizeTimer) {
			clearTimeout(resizeTimer);
		}
		resizeTimer = setTimeout(function(){
			var _w1 = document.documentElement.clientWidth;
			var _w2 = document.body.clientWidth;
			if ((_w1 || _w2) <= 1100) {
				if (swiper.params.slidesPerGroup != 1) {
					swiper.params.slidesPerGroup = 1;
					swiper.params.slidesPerView = 1;
					swiper.resizeFix();
				}
			}else if ((_w1 || _w2) <= 1360) {
				if (swiper.params.slidesPerGroup != 2) {
					swiper.params.slidesPerGroup = 2;
					swiper.params.slidesPerView = 2;
					swiper.resizeFix();
				}
			}else {
				if (swiper.params.slidesPerGroup != 3) {
					swiper.params.slidesPerGroup = 3;
					swiper.params.slidesPerView = 3;
					swiper.resizeFix();
				}
			}
		}, 100);
	});
}

function swiperBox_responsive_5(box) {
	var swiper = new Swiper(box + ' .swiper-container', {
        pagination: box + ' .swiper-pagination',
        paginationClickable: true,
        calculateHeight: true,
        slidesPerGroup: 5,
        slidesPerView: 5,
        spaceBetween: 10,
        loop: true
    });
    jQuery(box + ' .swiper-box-arrow-prev').click(function(){
		swiper.swipePrev();
	});
	jQuery(box + ' .swiper-box-arrow-next').click(function(){
		swiper.swipeNext();
	});
	
	var _w1 = document.documentElement.clientWidth;
	var _w2 = document.body.clientWidth;
	if ((_w1 || _w2) <= 1020) {
		swiper.params.slidesPerGroup = 2;
		swiper.params.slidesPerView = 2;
		swiper.reInit();
		swiper.resizeFix();
	}else if ((_w1 || _w2) <= 1200) {
		swiper.params.slidesPerGroup = 3;
		swiper.params.slidesPerView = 3;
		swiper.reInit();
		swiper.resizeFix();
	}else if ((_w1 || _w2) <= 1560) {
		swiper.params.slidesPerGroup = 4;
		swiper.params.slidesPerView = 4;
		swiper.reInit();
		swiper.resizeFix();
	}
	
	var resizeTimer = null;
	$(window).bind('resize', function(e){
		if (resizeTimer) {
			clearTimeout(resizeTimer);
		}
		resizeTimer = setTimeout(function(){
			var _w1 = document.documentElement.clientWidth;
			var _w2 = document.body.clientWidth;
			if ((_w1 || _w2) <= 1020) {
				if (swiper.params.slidesPerGroup != 2) {
					swiper.params.slidesPerGroup = 2;
					swiper.params.slidesPerView = 2;
					swiper.resizeFix();
				}
			}else if ((_w1 || _w2) <= 1200) {
				if (swiper.params.slidesPerGroup != 3) {
					swiper.params.slidesPerGroup = 3;
					swiper.params.slidesPerView = 3;
					swiper.resizeFix();
				}
			}else if ((_w1 || _w2) <= 1560) {
				if (swiper.params.slidesPerGroup != 4) {
					swiper.params.slidesPerGroup = 4;
					swiper.params.slidesPerView = 4;
					swiper.resizeFix();
				}
			}else {
				if (swiper.params.slidesPerGroup != 5) {
					swiper.params.slidesPerGroup = 5;
					swiper.params.slidesPerView = 5;
					swiper.resizeFix();
				}
			}
		}, 100);
	});
}