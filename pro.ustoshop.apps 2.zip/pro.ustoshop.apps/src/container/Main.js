import React, { Component } from 'react';
import './Main.css';

class Main extends Component {
  render() {
    return (
        <div className="_main">
            <div className="_container">
                <img src="../images/banner.png" />
            </div>
        </div>
    );
  }
}

export default Main;
