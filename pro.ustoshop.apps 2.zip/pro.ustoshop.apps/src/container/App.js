import React, { Component } from 'react';
import '../component/Base.css';
import Header from "../component/Header";
import Main from "./Main";
import List from "../component/_module_/List";
import Banner from "../component/_module_/Banner";
import CashTotal from "../component/_module_/CashTotal";
import Item from "../component/_module_/Item";
import Title from "../component/_module_/Title";

class App extends Component {
  
  render() {
    const listData = ["Shirts & Tops","Dresses", "Pants", "Active Wear", "Active Wear", "Jeans", "Jeans", "Activewear"];
    const bannerData = [
      {url:"/files/images/banner-0.jpg", title:"Nulla vitae elit libero, a pharetra augue mollis interdum.0", info:"information0"},
      {url:"/files/images/banner-1.jpg", title:"Nulla vitae elit libero, a pharetra augue mollis interdum.1", info:"information1"},
    ]
    const cashTotal = "121,324,234.43";

    const itemData = {
      src: "/files/images/ipad.jpg",
      href: "/test/",
      title: "Apple iPad mini 4 Wi-Fi 128GB Silver",
      wasPrice: "$193.00",
      finalPrice: "$150.00",
      from: "USTOSHOP.COM MarketPlace",
      cashback: "+ $0.56",
      shipping: "Fedex"
    }

    return (
      <div className="App">
        <Header />
        <div className="_main">
          <div className="_container">
            <Banner ListData={bannerData}/>
            <CashTotal Total={cashTotal}/>
            <List ListData={listData}  ListTitle="Closths"/>

            <Item ItemData={itemData}/>

            <Title title="This is title." />
            
          </div>
        </div>
        
        
        
      </div>
    );
  }
}

export default App;
