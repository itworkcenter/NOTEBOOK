import React, { Component } from 'react';
import './List.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class Price extends Component {
    
  render() {
    const price = this.props.PriceData;
    let regex = new RegExp('^(\\$|¥)(\\d+)\.(\\d+)$', "ig");
    let priceArr = price.match(regex);

    return (
        <span className="_price">
            <span className="_price-currency">{ RegExp.$1 }</span>
            <span className="_price-characteristic">{ RegExp.$2 }</span>
            <span className="_price-mark">.</span>
            <span className="_price-mantissa">{ RegExp.$3 }</span>
        </span> 

        
    );
  }
}

export default Price;

