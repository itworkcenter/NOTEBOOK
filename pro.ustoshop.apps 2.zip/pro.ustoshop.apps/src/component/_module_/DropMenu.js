import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import "./DropMenu.css";
import { 
    Form, 
    FormGroup, 
    ControlLabel,
    FormControl,
    InputGroup,
    Dropdown,
    DropdownButton,
    NavDropdown,
    MenuItem,
    Button } from 'react-bootstrap';

class DropMenuToggle extends Component {
    constructor(props, context) {
        super(props, context);
    
        // this.handleClick = this.handleClick.bind(this);
        this.handleHover = this.handleHover.bind(this);
    }
    
    // handleClick(e) {
    //     e.preventDefault();
    //     // this.props.onClick(e);
    //     this.props.onMouseEnter(e);
    // }
    handleHover(e) {
        e.preventDefault();
        this.props.onClick(e);
    }
    
    render() {
        return (
        <a class="dropdown-toggle" href="" onMouseEnter={this.handleHover}>
            <FontAwesomeIcon icon="bars" />
            <span> {this.props.children} </span>
        </a>
        );
    }
}

class DropMenuList extends Component {
    constructor(props, context) {
        super(props, context);
    
        this.handleChange = this.handleChange.bind(this);
    
        this.state = {
        value: ''
        };
    }
    
    handleChange(e) {
        this.setState({ value: e.target.value });
    }
    
    focusNext() {
        const input = ReactDOM.findDOMNode(this.input);
    
        if (input) {
        input.focus();
        }
    }
    
    render() {
        const { children } = this.props;
        const { value } = this.state;
    
        return (
        <div className="dropdown-menu">
            <ul className="list-unstyled">
            {React.Children.toArray(children).filter(
                child => !value.trim() || child.props.children.indexOf(value) !== -1
            )}
            </ul>
        </div>
        );
    }
}
    

class DropMenu extends Component {
    render() {
      const menuData = ["Clothes", "Shoes", "Beauty", "Electronics", "Health & Nutrition", "Kids", "Travel", "Groceries", "Shopping", "Essentials", "Stores"];
      return (
       <Dropdown id="dropdown-custom-menu">
          <DropMenuToggle bsRole="toggle">Categories</DropMenuToggle>
      
          <DropMenuList bsRole="menu">
              {menuData.map((name)=>( <MenuItem eventKey={4}>{name}</MenuItem>))}
          </DropMenuList>
      </Dropdown>
      );
    }
  }

  export default DropMenu;