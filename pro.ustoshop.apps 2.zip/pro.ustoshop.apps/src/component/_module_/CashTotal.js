import React, { Component } from 'react';
import './CashTotal.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class CashTotal extends Component {
  render() {
    return (
        <div className="_cashtotal">
          $<span className="_cashtotal-num">{this.props.Total} </span> awarded in Cashback!
        </div>
    );
  }
}

export default CashTotal;

