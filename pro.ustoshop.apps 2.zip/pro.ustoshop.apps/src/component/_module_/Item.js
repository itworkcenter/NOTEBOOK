import React, { Component } from 'react';
import './Item.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import Price from "./Price";

class Item extends Component {

  render(){

    const data = this.props.ItemData;

    return (
        <div className="_item">
            <a href={ data.href }>
                <div className="_item-media sqr">
                    <div className="sqr-inner">
                        <img src={ data.src } title={ data.title } />
                    </div>
                </div>
                <h3 className="_item-title">{ data.title }</h3>
                <ul className="_item-feature">
                    <li className="was-price"><Price PriceData = { data.wasPrice }/></li>
                    <li className="final-price"> {data.finalPrice}</li>
                    <li className="from"> { data.from }</li>
                    <li className="cashback"> { data.cashback }</li>
                    <li className="shipping"> { data.shipping }</li>
                </ul>
            </a>
        </div> 
    );
  }

  
}

export default Item;