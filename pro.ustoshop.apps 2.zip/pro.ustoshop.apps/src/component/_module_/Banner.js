import React, { Component } from 'react';
import './Banner.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import {Carousel} from 'react-bootstrap';

class List extends Component {
  render() {
    return (
        <div className="_banner">
            <Carousel>
                {/* {this.props.ListData.forEach((data)=>
                    <Carousel.Item>
                         {console.log(data)}
                        <img src={data.url} />
                        <Carousel.Caption>
                        <h3>{data.title}</h3>
                        <p>{data.info}</p>
                        </Carousel.Caption>
                    </Carousel.Item>
                )} */}
                <Carousel.Item>
                    <img src="/files/images/banner-0.jpg" />
                    <Carousel.Caption>
                    <h3>fsfsdf</h3>
                    <p>sfsdfsdf</p>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img src="/files/images/banner-1.jpg" />
                    <Carousel.Caption>
                    <h3>fsfsdf</h3>
                    <p>sfsdfsdf</p>
                    </Carousel.Caption>
                </Carousel.Item>
                
            </Carousel>
        </div>
    );
  }
}

export default List;

