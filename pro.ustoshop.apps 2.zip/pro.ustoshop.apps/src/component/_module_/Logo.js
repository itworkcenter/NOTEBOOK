import React, { Component } from 'react';
import './Logo.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import Icon, { faCoffee } from '@fortawesome/fontawesome-free-solid'

class Logo extends Component {
  render() {
    return (
        <div className="_logo">
          <a href="/">
            <div className="_logo-icon"><FontAwesomeIcon icon={faCoffee} /></div>
            <div className="_logo-text _web inline">Ustoshop</div>
          </a>
        </div>
    );
  }
}

export default Logo;

