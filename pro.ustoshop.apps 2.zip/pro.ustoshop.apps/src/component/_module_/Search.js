import React, { Component } from 'react';
import './Search.css';
import { 
    Form, 
    FormGroup, 
    ControlLabel,
    FormControl,
    InputGroup,
    Button } from 'react-bootstrap';
    

class Search extends Component {
    onSearchChange = e => {
        this.setState({searchText: e.target.value});
    } 
    handleSubmit = e => {
        e.preventDefault();
        this.props.onSearch(this.state.searchText);
        e.currentTarget.reset();
      }
  render() {
    return (
        <Form onSubmit={this.handleSubmit}>
            <FormGroup>
                <InputGroup>
                    <FormControl type="text"  onChange={this.onSearchChange}/>
                    <InputGroup.Addon>Search</InputGroup.Addon>
                </InputGroup>
            </FormGroup>
        </Form>
    );
  }
}

export default Search;
