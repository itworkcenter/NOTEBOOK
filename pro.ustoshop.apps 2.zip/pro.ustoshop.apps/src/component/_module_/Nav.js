import React, { Component } from 'react';
import './Nav.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import NavMenu from './NavMenu';

class Nav extends Component {
  render() {
    return (
        <nav className="_nav">
          <NavMenu />
        </nav>
    );
  }
}

export default Nav;

