import React, { Component } from 'react';
import './Header.css';
import '../component/_module_/Logo';
import Logo from '../component/_module_/Logo';
import Nav from '../component/_module_/Nav';
import NavMobi from '../component/_module_/NavMobi';
import Search from '../component/_module_/Search';
import axios from 'axios';


class Header extends Component {

    performSearch = (query) => {
        axios.get(`http://api.giphy.com/v1/gifs/search?q=${query}&limit=24&api_key=dc6zaTOxFJmzC`)
            .then(response => {
                let data = response.data.data;
                this.setState({
                    gifs: data
                });
            })
            .catch(error => {
                console.log('Error fetching and parsing data', error);
            });    
    }
    
  render() {
    return (
        <header className="_header">
            <div className="_container">
                <div className="_table">
                    <div className="_header-cell _table-cell _mobile">
                        <NavMobi/>
                    </div>
                    <div className="_header-cell _table-cell">
                    <Logo/>
                    </div>
                    <div className="_header-cell _table-cell _web">
                        <Nav/>
                    </div>
                    <div className="_header-cell _table-cell _header-search">
                        <Search onSearch={ this.performSearch }/>
                    </div>
                    <div className="_header-cell _table-cell">Sign In</div>
                    <div className="_header-cell _table-cell">Cart</div>
                </div>
            </div>
            
        </header>
        
    )
  }
}

export default Header;
