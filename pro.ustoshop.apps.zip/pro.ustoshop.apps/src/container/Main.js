import React, { Component } from 'react';
import './Main.css';

class Main extends Component {
  render() {
    return (
        <div className="usto-main">
            <div className="usto-container">
                <img src="../images/banner.png" />
            </div>
        </div>
    );
  }
}

export default Main;
