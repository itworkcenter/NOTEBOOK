import React, { Component } from 'react';
import './Header.css';
import '../component/_module_/Logo';
import Logo from '../component/_module_/Logo';
import Nav from '../component/_module_/Nav';
import NavMobi from '../component/_module_/NavMobi';
import Search from '../component/_module_/Search';

class Header extends Component {
  render() {
    return (
        <header className="usto-header">
            <div className="usto-container">
                <div className="usto-table">
                    <div className="usto-header-cell usto-table-cell usto-mobile">
                        <NavMobi/>
                    </div>
                    <div className="usto-header-cell usto-table-cell">
                    <Logo/>
                    </div>
                    <div className="usto-header-cell usto-table-cell usto-web">
                        <Nav/>
                    </div>
                    <div className="usto-header-cell usto-table-cell usto-header-search">
                        <Search />
                    </div>
                    <div className="usto-header-cell usto-table-cell">Sign In</div>
                    <div className="usto-header-cell usto-table-cell">Cart</div>
                </div>
            </div>
        </header>
    );
  }
}

export default Header;
