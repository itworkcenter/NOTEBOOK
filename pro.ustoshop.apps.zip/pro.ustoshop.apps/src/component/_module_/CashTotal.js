import React, { Component } from 'react';
import './CashTotal.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class CashTotal extends Component {
  render() {
    return (
        <div className="usto-cashtotal">
          $<span className="usto-cashtotal-num">{this.props.Total} </span> awarded in Cashback!
        </div>
    );
  }
}

export default CashTotal;

