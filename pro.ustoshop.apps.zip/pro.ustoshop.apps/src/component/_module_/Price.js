import React, { Component } from 'react';
import './List.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class Price extends Component {
    
  render() {
    const price = this.props.PriceData;
    let regex = new RegExp('^(\\$|¥)(\\d+)\.(\\d+)$', "ig");
    let priceArr = price.match(regex);

    return (
        <span className="usto-Price">
            <span className="usto-price-currency">{ RegExp.$1 }</span>
            <span className="usto-price-characteristic">{ RegExp.$2 }</span>
            <span className="usto-price-mark">.</span>
            <span className="usto-price-mantissa">{ RegExp.$3 }</span>
        </span> 

        
    );
  }
}

export default Price;

