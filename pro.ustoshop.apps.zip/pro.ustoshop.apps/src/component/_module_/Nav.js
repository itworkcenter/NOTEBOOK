import React, { Component } from 'react';
import './Nav.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import NavMenu from './NavMenu';

class Nav extends Component {
  render() {
    return (
        <nav className="usto-nav">
          <NavMenu />
        </nav>
    );
  }
}

export default Nav;

