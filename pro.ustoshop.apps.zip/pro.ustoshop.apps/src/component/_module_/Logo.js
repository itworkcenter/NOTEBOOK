import React, { Component } from 'react';
import './Logo.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import Icon, { faCoffee } from '@fortawesome/fontawesome-free-solid'

class Logo extends Component {
  render() {
    return (
        <div className="usto-logo">
          <a href="/">
            <div className="usto-logo-icon"><FontAwesomeIcon icon={faCoffee} /></div>
            <div className="usto-logo-text usto-web inline">Ustoshop</div>
          </a>
        </div>
    );
  }
}

export default Logo;

