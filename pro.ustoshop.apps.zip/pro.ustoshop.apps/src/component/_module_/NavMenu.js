import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import './NavMenu.css';
import DropMenu from './DropMenu';

class NavMenu extends Component {
    render() {
        const menuData = ["Clothes", "Shoes", "Beauty", "Electronics", "Health & Nutrition", "Kids", "Travel", "Groceries", "Shopping", "Essentials", "Stores"];
        return (
        <div className="nav-menu">
            <div className="nav-menu-toggle"> Categories </div>

            <ul className="nav-menu-list">
                <li>"Clothes"</li>
                <li>"Clothes"</li>
                <li>"Clothes"</li>
                <li>"Clothes"</li>
                <li>"Clothes"</li>
                <li>"Clothes"</li>
                <li>"Clothes"</li>
            </ul>
        
        </div>
        );
    }
}


export default NavMenu;
