import React, { Component } from 'react';
import './Search.css';
import { 
    Form, 
    FormGroup, 
    ControlLabel,
    FormControl,
    InputGroup,
    Button } from 'react-bootstrap';
    

class Search extends Component {
  render() {
    return (
        <Form>
            <FormGroup>
            <InputGroup>
                <FormControl type="text" />
                <InputGroup.Addon>Search</InputGroup.Addon>
            </InputGroup>
            </FormGroup>
        </Form>
    );
  }
}

export default Search;
