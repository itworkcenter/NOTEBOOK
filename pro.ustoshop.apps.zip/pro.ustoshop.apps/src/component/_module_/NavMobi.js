import React, { Component } from 'react';
import './Nav.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class NavMobi extends Component {
  render() {
    return (
        <nav className="usto-nav">
          <a href="/">
            <div className="usto-nav-icon"><FontAwesomeIcon icon="bars" /></div>
          </a>
        </nav>
    );
  }
}

export default NavMobi;

