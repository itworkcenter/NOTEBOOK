import React, { Component } from 'react';
import './List.css';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';

class List extends Component {
  render() {
    return (
        <div className="usto-list">
            <h3 className="usto-list-title">{this.props.ListTitle}</h3>
            <ul className="usto-list-main">
              {this.props.ListData.map((name)=>(
                <li className="usto-list-item"> <a href="{}"> {name} </a> </li>
              ))}
            </ul>
        </div> 
    );
  }
}

export default List;

